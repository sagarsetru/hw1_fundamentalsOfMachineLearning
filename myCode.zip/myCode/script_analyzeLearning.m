%% load learning errors
cd '/Users/sagarsetru/Documents/Princeton/cos424/hw1/voxResources/myData/fisherVectors';
% pick up .mat files
featFiles = uipickfiles;
%%